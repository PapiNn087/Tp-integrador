
/* ========================================
   LISTA DE PRODUCTOS
======================================== */

const productos = [

    {
        nombre: "RTX 5070",
        categoria: "placas",
        precio: 850000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=RTX+5070"
    },

    {
        nombre: "RTX 4060",
        categoria: "placas",
        precio: 550000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=RTX+4060"
    },

    {
        nombre: "RTX 3060",
        categoria: "placas",
        precio: 420000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=RTX+3060"
    },

    {
        nombre: "Ryzen 7 5700X",
        categoria: "procesadores",
        precio: 280000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Ryzen+7"
    },

    {
        nombre: "Ryzen 5 5600",
        categoria: "procesadores",
        precio: 190000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Ryzen+5"
    },

    {
        nombre: "Intel Core i5 12400F",
        categoria: "procesadores",
        precio: 230000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Intel+i5"
    },

    {
        nombre: "Kingston Fury 16GB",
        categoria: "memorias",
        precio: 85000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Kingston+16GB"
    },

    {
        nombre: "Corsair Vengeance 32GB",
        categoria: "memorias",
        precio: 150000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Corsair+32GB"
    },

    {
        nombre: "Samsung 990 EVO 1TB",
        categoria: "almacenamiento",
        precio: 180000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Samsung+SSD"
    },

    {
        nombre: "Kingston NV2 500GB",
        categoria: "almacenamiento",
        precio: 75000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Kingston+SSD"
    },

    {
        nombre: "MSI B550 Gaming",
        categoria: "motherboards",
        precio: 210000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=MSI+B550"
    },

    {
        nombre: "Corsair 750W",
        categoria: "fuentes",
        precio: 160000,
        imagen: "https://placehold.co/600x400/15152b/ffffff?text=Corsair+750W"
    }

];


/* ========================================
   ELEMENTOS DEL HTML
======================================== */

const buscador = document.getElementById("buscador");
const categoria = document.getElementById("categoria");

const precioMin = document.getElementById("precio-min");
const precioMax = document.getElementById("precio-max");

const limpiarFiltros = document.getElementById("limpiar-filtros");

const contenedorProductos = document.getElementById("productos");
const cantidadResultados = document.getElementById("cantidad-resultados");


/* ========================================
   FORMATO DE PRECIOS
======================================== */

function formatoPrecio(precio) {

    return precio.toLocaleString("es-AR", {
        style: "currency",
        currency: "ARS",
        maximumFractionDigits: 0
    });

}


/* ========================================
   MOSTRAR PRODUCTOS
======================================== */

function mostrarProductos() {

    // Obtenemos los valores de los filtros

    const textoBusqueda = buscador.value.toLowerCase();
    const categoriaSeleccionada = categoria.value;

    const minimo = precioMin.value === ""
        ? 0
        : Number(precioMin.value);

    const maximo = precioMax.value === ""
        ? Infinity
        : Number(precioMax.value);


    // Filtramos los productos

    const productosFiltrados = productos.filter(producto => {

        const coincideNombre = producto.nombre
            .toLowerCase()
            .includes(textoBusqueda);

        const coincideCategoria =
            categoriaSeleccionada === "todos" ||
            producto.categoria === categoriaSeleccionada;

        const coincidePrecio =
            producto.precio >= minimo &&
            producto.precio <= maximo;

        return coincideNombre &&
               coincideCategoria &&
               coincidePrecio;

    });


    // Limpiamos el catálogo anterior

    contenedorProductos.innerHTML = "";


    // Mostramos la cantidad de resultados

    cantidadResultados.textContent =
        productosFiltrados.length + " productos encontrados";


    // Si no hay productos disponibles

    if (productosFiltrados.length === 0) {

        contenedorProductos.innerHTML =
            '<p class="sin-resultados">No se encontraron productos.</p>';

        return;

    }


    // Creamos las tarjetas de productos

    productosFiltrados.forEach(producto => {

        const tarjeta = document.createElement("div");

        tarjeta.classList.add("producto");

        tarjeta.innerHTML = `
            <img src="${producto.imagen}" alt="${producto.nombre}">

            <h3>${producto.nombre}</h3>

            <p class="categoria-texto">${producto.categoria}</p>

            <p>${formatoPrecio(producto.precio)}</p>
        `;

        contenedorProductos.appendChild(tarjeta);

    });

}


/* ========================================
   EVENTOS DE LOS FILTROS
======================================== */

// Buscar mientras escribimos

buscador.addEventListener("input", mostrarProductos);


// Filtrar por categoría

categoria.addEventListener("change", mostrarProductos);


// Filtrar por precio

precioMin.addEventListener("input", mostrarProductos);
precioMax.addEventListener("input", mostrarProductos);


// Limpiar todos los filtros

limpiarFiltros.addEventListener("click", function() {

    buscador.value = "";
    categoria.value = "todos";

    precioMin.value = "";
    precioMax.value = "";

    mostrarProductos();

});


/* ========================================
   CARRUSEL DE PRODUCTOS DESTACADOS
======================================== */

// Seleccionamos los primeros seis productos

const productosDestacados = productos.slice(0, 6);


// Elementos del carrusel

const productoDestacado = document.getElementById("producto-destacado");

const botonAnterior = document.getElementById("anterior");
const botonSiguiente = document.getElementById("siguiente");

const indicadores = document.getElementById("indicadores");


// Índice del producto que se está mostrando

let indiceActual = 0;


// Mostramos el producto destacado

function mostrarDestacado() {

    const producto = productosDestacados[indiceActual];

    productoDestacado.innerHTML = `

        <img src="${producto.imagen}" alt="${producto.nombre}">

        <h3>${producto.nombre}</h3>

        <p>${formatoPrecio(producto.precio)}</p>

    `;


    // Actualizamos los indicadores

    const botonesIndicadores = document.querySelectorAll(".indicador");

    botonesIndicadores.forEach((boton, indice) => {

        boton.classList.toggle(
            "activo",
            indice === indiceActual
        );

    });

}


// Creamos los indicadores del carrusel

productosDestacados.forEach((producto, indice) => {

    const boton = document.createElement("button");

    boton.classList.add("indicador");

    boton.setAttribute("aria-label", "Mostrar " + producto.nombre);

    boton.addEventListener("click", function() {

        indiceActual = indice;

        mostrarDestacado();

        reiniciarTemporizador();

    });

    indicadores.appendChild(boton);

});


// Botón para avanzar

botonSiguiente.addEventListener("click", function() {

    indiceActual++;

    if (indiceActual >= productosDestacados.length) {
        indiceActual = 0;
    }

    mostrarDestacado();

    reiniciarTemporizador();

});


// Botón para retroceder

botonAnterior.addEventListener("click", function() {

    indiceActual--;

    if (indiceActual < 0) {
        indiceActual = productosDestacados.length - 1;
    }

    mostrarDestacado();

    reiniciarTemporizador();

});


/* ========================================
   CAMBIO AUTOMÁTICO DEL CARRUSEL
======================================== */

let temporizador;

function iniciarTemporizador() {

    temporizador = setInterval(function() {

        indiceActual++;

        if (indiceActual >= productosDestacados.length) {
            indiceActual = 0;
        }

        mostrarDestacado();

    }, 4000);

}


// Reiniciamos el tiempo cuando el usuario interactúa

function reiniciarTemporizador() {

    clearInterval(temporizador);

    iniciarTemporizador();

}


/* ========================================
   INICIAR LA PÁGINA
======================================== */

// Mostramos los productos del catálogo

mostrarProductos();


// Mostramos el primer producto destacado

mostrarDestacado();


// Iniciamos el carrusel automático

iniciarTemporizador();
