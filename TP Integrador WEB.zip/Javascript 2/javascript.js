
/* ========================================
   LISTA DE PRODUCTOS
======================================== */

const productos = [

    {
        nombre: "RTX 5070",
        categoria: "placas",
        precio: 850000,
        imagen: "https://www.zotac.com/download/files/styles/w1024/public/product_gallery/graphics_cards/zt-b50700j-10p-image01.jpg?itok=8nI1QmX_"
    },

    {
        nombre: "RTX 4060",
        categoria: "placas",
        precio: 550000,
        imagen: "https://http2.mlstatic.com/D_NQ_NP_967271-MLA71810065851_092023-O.webp"
    },

    {
        nombre: "RTX 3060",
        categoria: "placas",
        precio: 420000,
        imagen: "https://m.media-amazon.com/images/I/61XAtpgr1lL._UXTMWIDTH_UYTMHEIGHT_.jpg"
    },

    {
        nombre: "Ryzen 7 5700X",
        categoria: "procesadores",
        precio: 280000,
        imagen: "https://mexx-img-2019.s3.amazonaws.com/Procesador-Amd-Ryzen-7-5700X-Ghz-AM4_42712_2.jpeg"
    },

    {
        nombre: "Ryzen 5 5600",
        categoria: "procesadores",
        precio: 190000,
        imagen: "https://www.maximus.com.ar/Temp/App_WebSite/App_PictureFiles/Items/100-100000927BOX_800.jpg"
    },

    {
        nombre: "Intel Core i5 12400F",
        categoria: "procesadores",
        precio: 230000,
        imagen: "https://fullh4rd.com.ar/img/productos/1/micro-intel-core-i5-12400f-svideo-s1700-0.jpg"
    },

    {
        nombre: "Kingston Fury 16GB",
        categoria: "memorias",
        precio: 85000,
        imagen: "https://fullh4rd.com.ar/img/productos/4/memoria-16gb-ddr4-3200-kingston-fury-beast-0.jpg"
    },

    {
        nombre: "Corsair Vengeance 32GB",
        categoria: "memorias",
        precio: 150000,
        imagen: "https://http2.mlstatic.com/D_NQ_NP_853397-MLA99980684701_112025-O.webp"
    },

    {
        nombre: "Samsung 990 EVO 1TB",
        categoria: "almacenamiento",
        precio: 180000,
        imagen: "https://http2.mlstatic.com/D_Q_NP_2X_709130-CBT117471855056_102026-P.webp"
    },

    {
        nombre: "Kingston NV2 500GB",
        categoria: "almacenamiento",
        precio: 75000,
        imagen: "https://http2.mlstatic.com/D_NQ_NP_646547-MLA81948362721_012025-O.webp"
    },

    {
        nombre: "MSI B550 Gaming",
        categoria: "motherboards",
        precio: 210000,
        imagen: "https://m.media-amazon.com/images/I/91oChAepmRL._UXTMWIDTH_UYTMHEIGHT_.jpg"
    },

    {
        nombre: "Corsair 750W",
        categoria: "fuentes",
        precio: 160000,
        imagen: "https://www.mastecnologia.com.ar/images/productos/14665.png"
    }

];


/* ========================================
   ELEMENTOS DEL HTML
======================================== */

const buscador = document.getElementById("buscador");
const categoria = document.getElementById("categoria");

const precioMin = document.getElementById("precio-min");
const precioMax = document.getElementById("precio-max");

const limpiarFiltros = document.getElementById("limpiar-filtros");

const contenedorProductos = document.getElementById("productos");
const cantidadResultados = document.getElementById("cantidad-resultados");


/* ========================================
   FORMATO DE PRECIOS
======================================== */

function formatoPrecio(precio) {

    return precio.toLocaleString("es-AR", {
        style: "currency",
        currency: "ARS",
        maximumFractionDigits: 0
    });

}


/* ========================================
   MOSTRAR PRODUCTOS
======================================== */

function mostrarProductos() {

    // Obtenemos los valores de los filtros

    const textoBusqueda = buscador.value.toLowerCase();
    const categoriaSeleccionada = categoria.value;

    const minimo = precioMin.value === ""
        ? 0
        : Number(precioMin.value);

    const maximo = precioMax.value === ""
        ? Infinity
        : Number(precioMax.value);


    // Filtramos los productos

    const productosFiltrados = productos.filter(producto => {

        const coincideNombre = producto.nombre
            .toLowerCase()
            .includes(textoBusqueda);

        const coincideCategoria =
            categoriaSeleccionada === "todos" ||
            producto.categoria === categoriaSeleccionada;

        const coincidePrecio =
            producto.precio >= minimo &&
            producto.precio <= maximo;

        return coincideNombre &&
               coincideCategoria &&
               coincidePrecio;

    });


    // Limpiamos el catálogo anterior

    contenedorProductos.innerHTML = "";


    // Mostramos la cantidad de resultados

    cantidadResultados.textContent =
        productosFiltrados.length + " productos encontrados";


    // Si no hay productos disponibles

    if (productosFiltrados.length === 0) {

        contenedorProductos.innerHTML =
            '<p class="sin-resultados">No se encontraron productos.</p>';

        return;

    }


    // Creamos las tarjetas de productos

    productosFiltrados.forEach(producto => {

        const tarjeta = document.createElement("div");

        tarjeta.classList.add("producto");

        tarjeta.innerHTML = `
            <img src="${producto.imagen}" alt="${producto.nombre}">

            <h3>${producto.nombre}</h3>

            <p class="categoria-texto">${producto.categoria}</p>

            <p>${formatoPrecio(producto.precio)}</p>
        `;

        contenedorProductos.appendChild(tarjeta);

    });

}


/* ========================================
   EVENTOS DE LOS FILTROS
======================================== */

// Buscar mientras escribimos

buscador.addEventListener("input", mostrarProductos);


// Filtrar por categoría

categoria.addEventListener("change", mostrarProductos);


// Filtrar por precio

precioMin.addEventListener("input", mostrarProductos);
precioMax.addEventListener("input", mostrarProductos);


// Limpiar todos los filtros

limpiarFiltros.addEventListener("click", function() {

    buscador.value = "";
    categoria.value = "todos";

    precioMin.value = "";
    precioMax.value = "";

    mostrarProductos();

});


/* ========================================
   CARRUSEL DE PRODUCTOS DESTACADOS
======================================== */

// Seleccionamos los primeros seis productos

const productosDestacados = productos.slice(0, 6);


// Elementos del carrusel

const productoDestacado = document.getElementById("producto-destacado");

const botonAnterior = document.getElementById("anterior");
const botonSiguiente = document.getElementById("siguiente");

const indicadores = document.getElementById("indicadores");


// Índice del producto que se está mostrando

let indiceActual = 0;


// Mostramos el producto destacado

function mostrarDestacado() {

    const producto = productosDestacados[indiceActual];

    productoDestacado.innerHTML = `

        <img src="${producto.imagen}" alt="${producto.nombre}">

        <h3>${producto.nombre}</h3>

        <p>${formatoPrecio(producto.precio)}</p>

    `;


    // Actualizamos los indicadores

    const botonesIndicadores = document.querySelectorAll(".indicador");

    botonesIndicadores.forEach((boton, indice) => {

        boton.classList.toggle(
            "activo",
            indice === indiceActual
        );

    });

}


// Creamos los indicadores del carrusel

productosDestacados.forEach((producto, indice) => {

    const boton = document.createElement("button");

    boton.classList.add("indicador");

    boton.setAttribute("aria-label", "Mostrar " + producto.nombre);

    boton.addEventListener("click", function() {

        indiceActual = indice;

        mostrarDestacado();

        reiniciarTemporizador();

    });

    indicadores.appendChild(boton);

});


// Botón para avanzar

botonSiguiente.addEventListener("click", function() {

    indiceActual++;

    if (indiceActual >= productosDestacados.length) {
        indiceActual = 0;
    }

    mostrarDestacado();

    reiniciarTemporizador();

});


// Botón para retroceder

botonAnterior.addEventListener("click", function() {

    indiceActual--;

    if (indiceActual < 0) {
        indiceActual = productosDestacados.length - 1;
    }

    mostrarDestacado();

    reiniciarTemporizador();

});


/* ========================================
   CAMBIO AUTOMÁTICO DEL CARRUSEL
======================================== */

let temporizador;

function iniciarTemporizador() {

    temporizador = setInterval(function() {

        indiceActual++;

        if (indiceActual >= productosDestacados.length) {
            indiceActual = 0;
        }

        mostrarDestacado();

    }, 4000);

}


// Reiniciamos el tiempo cuando el usuario interactúa

function reiniciarTemporizador() {

    clearInterval(temporizador);

    iniciarTemporizador();

}


/* ========================================
   INICIAR LA PÁGINA
======================================== */

// Mostramos los productos del catálogo

mostrarProductos();


// Mostramos el primer producto destacado

mostrarDestacado();


// Iniciamos el carrusel automático

iniciarTemporizador();
